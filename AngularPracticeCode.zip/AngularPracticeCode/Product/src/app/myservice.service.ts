import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyserviceService {
  http:HttpClient;
  product:Product[]=[];
  fetched:boolean=false;
  constructor(http:HttpClient) { 
    this.http=http;
    this.fetchProduct();
  }

  fetchProduct(){
    this.http.get('./assets/db.json').subscribe(
      data=>{
        if(!this.fetched){
          this.convert(data['products']);
          this.fetched=true;
        }
      }
    );
  }

  convert(data:any){
for(let o of data){
  let p = new Product(o.id,o.name,o.price,o.category);
  this.product.push(p);
}
  }

  getProduct():Product[]{
    return this.product;
  }

  foundIndex:number=-1;
delete(id:string){
  let p:Product;
    for(let i=0;i<this.product.length;i++){
      p=this.product[i];
      if(p.id==id){
        //console.log(id);
        this.foundIndex=i;
        this.product.splice(this.foundIndex,1);
      }
    }

}

search(id:string):Product[]{
  let res:Product[]=[];
  let p:Product;let flag=0;
  for(let i=0;i<this.product.length;i++){
    p=this.product[i];
    if(p.id==id){
      res.push(p);flag=1;}
  }
  if(flag==0)
  alert(id+" doesn't exist");
  return res;
}

}


export class Product{
  id:string;
  name:string;
  price:number;
  category:string;
  constructor(id:string,name:string,price:number,category:string){
      this.id=id;
      this.name=name;
      this.price=price;
      this.category=category;
  }
}