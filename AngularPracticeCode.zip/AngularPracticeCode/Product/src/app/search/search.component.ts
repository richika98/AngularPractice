import { Component, OnInit } from '@angular/core';
import { MyserviceService, Product } from '../myservice.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  service:MyserviceService;
  constructor(service:MyserviceService) { 
    this.service=service;
  }
product:Product[]=[];
  searched:boolean=true;
  search(data:any){
    let id:string=data.id;
    this.product=this.service.search(id);
    if(this.product.length>0)
      this.searched=!this.searched;
  }

  ngOnInit() {
  }

}
