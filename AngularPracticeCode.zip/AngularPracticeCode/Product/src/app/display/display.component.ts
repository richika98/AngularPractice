import { Component, OnInit } from '@angular/core';
import { MyserviceService, Product } from '../myservice.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {
service:MyserviceService;
product:Product[]=[];
  constructor(service:MyserviceService) { 
    this.service=service;
  }

  delete(id:string){
    this.service.delete(id);
    this.product=this.service.getProduct();

  }

  order:boolean=true;
  column:string="id";
  sort(column:string){
    if(this.column=column){
     //this.order=!this.order;
    }
    else{
      this.order=true;
      this.column=column;
    }
  }



  ngOnInit() {
this.product=this.service.getProduct();
  }

}
