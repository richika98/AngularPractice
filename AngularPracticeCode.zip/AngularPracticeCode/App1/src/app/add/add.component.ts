import { Component, OnInit } from '@angular/core';
import { MyServiceService, Mobile } from '../my-service.service';

@Component({
  selector: 'app-add',
  templateUrl: './add.component.html',
  styleUrls: ['./add.component.css']
})
export class AddComponent implements OnInit {
service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  add(data:any){
   let mob=new Mobile(data.id,data.name,data.price);
    this.service.add(mob);

  }

  ngOnInit() {
  }

}
