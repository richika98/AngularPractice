import { Component, OnInit } from '@angular/core';
import { MyServiceService, Mobile } from '../my-service.service';

@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  mobile:Mobile[]=[];
  searched:boolean=true;
  search(data:any){
    let id:number=data.id;
    this.mobile=this.service.search(id);
    if(this.mobile.length>0)
      this.searched=!this.searched;
  }

  ngOnInit() {
  }

}
