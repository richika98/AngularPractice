import { Component, OnInit } from '@angular/core';
import { MyServiceService, Mobile } from '../my-service.service';

@Component({
  selector: 'app-update',
  templateUrl: './update.component.html',
  styleUrls: ['./update.component.css']
})
export class UpdateComponent implements OnInit {
service:MyServiceService;
  constructor(service:MyServiceService) { 
    this.service=service;
  }
mobile:Mobile[]=[];

updated:boolean=true;
  update(data:any){
    this.updated=this.service.update(data);
    this.mobile=this.service.getMobile();
  }

  ngOnInit() {
  }

}
