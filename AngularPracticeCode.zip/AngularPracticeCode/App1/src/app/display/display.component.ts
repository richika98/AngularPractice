import { Component, OnInit } from '@angular/core';
import { MyServiceService, Mobile } from '../my-service.service';

@Component({
  selector: 'app-display',
  templateUrl: './display.component.html',
  styleUrls: ['./display.component.css']
})
export class DisplayComponent implements OnInit {

  service:MyServiceService;
  mobile:Mobile[]=[];

  constructor(service:MyServiceService) { 
    this.service=service;
  }

  ngOnInit() {
    this.service.fetchMobile();
    this.mobile=this.service.getMobile();
  }

  delete(id:number){
this.service.delete(id);
this.mobile=this.service.getMobile();

  }

  column:string='id';
  order:boolean=true;
  sort(column:string){
    if(this.column==column){
      this.order=!this.order;
    }
    else{
      this.order=true;
      this.column=column;
    }

  }

}
