import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MyServiceService {
  
http:HttpClient;
mobile:Mobile[]=[];
fetched:boolean=false;

constructor(http:HttpClient) { 
  this.http=http;
}

fetchMobile(){
  this.http.get('./assets/mobile.json').subscribe(
    data=>{
      if(!this.fetched){
        this.convert(data);
        this.fetched=true;
      }
    }
  );}

  convert(data:any){
    for(let o of data){
      let m=new Mobile(o.mobId,o.mobName,o.mobPrice);
      this.mobile.push(m);
    }
  }
  getMobile():Mobile[]{
    return this.mobile;
  }

  deleteIndex=-1;
  delete(id:number){
    let mob:Mobile;
    for(let i=0;i<this.mobile.length;i++){
      mob=this.mobile[i];
      if(id==mob.mobId){
        this.deleteIndex=i;
      this.mobile.splice(this.deleteIndex,1);
      }
    }
  }

  add(mob: Mobile) {
   this.mobile.push(mob);
   alert("Added");
  }

  update(data:any){
    let flag=0;
    let mob:Mobile;
    for(let i=0;i<this.mobile.length;i++){
      mob=this.mobile[i];
      if(data.id==mob.mobId){
        this.mobile[i].mobName=data.name;
        this.mobile[i].mobPrice=data.price;
        flag=1;
        break;
    }
  }

  if(flag==0){
    alert(data.id+ "  doesn't exists");return true;
}
else return false;
  }

  search(data:number):Mobile[]{
    let flag=0;
    let res:Mobile[]=[];
    let mob:Mobile;
    for(let i=0;i<this.mobile.length;i++){
      mob=this.mobile[i];
      if(data==mob.mobId){
        res.push(mob);
        flag=1;
      }
  }
  if(flag==0){
    alert("No Data found");
    return res;
  }
  else
  return res;


}
}




export class Mobile{
  mobId:number;
  mobName:string;
  mobPrice:number;
  constructor( mobId:number, mobName:string, mobPrice:number){
this.mobId=mobId;
this.mobName=mobName;
this.mobPrice=mobPrice;
  }
} 