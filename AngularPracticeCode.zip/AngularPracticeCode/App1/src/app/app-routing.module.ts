import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { DisplayComponent } from './display/display.component';
import { AddComponent } from './add/add.component';
import { UpdateComponent } from './update/update.component';
import { SearchComponent } from './search/search.component';


const routes: Routes = [
  {
    path:'display',
    component:DisplayComponent
  },
  {
    path:'add',
    component:AddComponent
  },
  {
    path:'update',
    component:UpdateComponent
  },
  {
    path:'search',
    component:SearchComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
