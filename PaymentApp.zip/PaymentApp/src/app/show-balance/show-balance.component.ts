import { Component, OnInit } from '@angular/core';
import { MyServiceService, Account } from '../my-service.service';
import { strictEqual } from 'assert';

@Component({
  selector: 'app-show-balance',
  templateUrl: './show-balance.component.html',
  styleUrls: ['./show-balance.component.css']
})
export class ShowBalanceComponent implements OnInit {
  service:MyServiceService;
  account:Account;
  constructor(service:MyServiceService) { 
    this.service=service;
  }

  model: any = {};
message:string;
ifExists:boolean=true;
  showBalance(data:any){
    let acc:string=data.account;
    if(acc=="")
    window.alert("Data not provided properly");
    else{
    this.account=this.service.showBalance(acc);
    this.ifExists=false;
    if(this.account==null){
      this.message="This account doesn't exists. Please try with valid account number";
    }
    else{
        this.message="Your current balance is : "+this.account.balance;
    }

  }
  }


  ngOnInit() {
  }

}
