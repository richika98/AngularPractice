import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { CreateComponent } from './create/create.component';
import { ShowBalanceComponent } from './show-balance/show-balance.component';
import { DepositComponent } from './deposit/deposit.component';
import { WithdrawComponent } from './withdraw/withdraw.component';
import { TransferComponent } from './transfer/transfer.component';
import { MiniStatementComponent } from './mini-statement/mini-statement.component';
import { HttpClient,HttpClientModule } from '@angular/common/http';
import { MyServiceService } from './my-service.service';

@NgModule({
  declarations: [
    AppComponent,
    CreateComponent,
    ShowBalanceComponent,
    DepositComponent,
    WithdrawComponent,
    TransferComponent,
    MiniStatementComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [HttpClient,MyServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
